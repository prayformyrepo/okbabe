<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Conversation_Message extends Model
{

}
