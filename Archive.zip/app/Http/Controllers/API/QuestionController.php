<?php

namespace App\Http\Controllers\API;

use App\Adviser;
use App\Adviser_to_category;
use App\Http\Controllers\Controller;
use App\Notification;
use App\Question;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
class QuestionController extends Controller
{
    public $successStatus = 200;

    public function add_question(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'adviser_category_id'=>'integer|required',
            'subject'=>'required',
            'text'=>'required',
            'is_private'=>'required|boolean'
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $user=Auth::user();
        if ($user->is_adviser==1){
            return response()->json(['error'=>'Unauthorized'], 401);

        }

        $question=new Question();
        $question->user_id=$user->id;
        $question->adviser_category_id=$request->adviser_category_id;
        $question->subject=$request->subject;
        $question->text=$request->text;
        $question->is_private=$request->is_private;
        $question->save();


        //send notification to related advisers
        $advisers=Adviser::all();
        foreach ($advisers as $adviser){
            $has_cat=Adviser_to_category::where('adviser_id',$adviser->id)->where('adviser_category_id',$request->adviser_category_id)->count();
            if ($has_cat!=0){
                $has_notif=Notification::where('user_id',$adviser->user_id)->where('type',2)->where('read_at',null)->count();
                if ($has_notif==0 ){
                    $notification=new Notification();
                    $notification->user_id=$adviser->user_id;
                    $notification->is_adviser=1;
                    $notification->data='یک پرسش جدید در زمینه کاری شما ثبت شده است';
                    $notification->type=2;
                    $notification->save();
                }
            }
        }
        $question=Question::find($question->id);
        return response()->json(['success' => $question], $this-> successStatus);
    }

    public function show_questions(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'show_all'=>'boolean',
            'self'=>'boolean',

        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }
        $user=Auth::user();
        if (isset($request->show_all)&& $request->show_all==1 && !isset($request->self)){
            $questions=Question::orderBy('id','DESC')->simplePaginate(10);
        }
        else if(isset($request->self)&& $request->self==1){
            if ($user->is_adviser==1){
                $adviser_id=Adviser::where('user_id',$user->id)->value('id');
                $adviser_categories=Adviser_to_category::where('adviser_id',$adviser_id)->get();
                $questions=[];
                foreach ($adviser_categories as $adviser_category){
                  $questionsArray = Question::where('adviser_category_id', $adviser_category->adviser_category_id)->orderBy('id', 'DESC')->simplePaginate(10);
                    array_push($questions,$questionsArray);
                }
            }else {
                $questions = Question::where('user_id', $user->id)->orderBy('id', 'DESC')->simplePaginate(10);
            }

        }else{
            $questions=Question::where('status',1)->orderBy('id','DESC')->simplePaginate(10);
        }

        return response()->json(['success' => $questions], $this-> successStatus);

    }

    public function accept_question(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'question_id'=>'required',
            'accept'=>'required|boolean'
        ]);
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 401);
        }

        $user=Auth::user();
        if ($user->is_adviser==0){
            return response()->json(['error'=>'Unauthorized'], 401);
        }
        @$question=Question::find($request->question_id);
        if (!isset($question)) return response()->json(['error'=>'not found'], 404);
        $question->status=$request->accept;
        $question->save();


        return response()->json(['success' => $question], $this-> successStatus);


    }

}
