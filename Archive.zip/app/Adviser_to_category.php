<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adviser_to_category extends Model
{
    //
}
