<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Saved_adviser extends Model
{
    //
}
