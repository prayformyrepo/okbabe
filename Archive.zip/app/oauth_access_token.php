<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class oauth_access_token extends Model
{
    //
}
